package pages;

import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SpecificDate {

	private WebDriver driver;

	public SpecificDate(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[@data-visible='true']/table/tbody")
	WebElement tableCalendar;
    public SpecificDate CalendarMethod()
	{
	Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
	 
    int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
    calendar.add(Calendar.DATE, 2);
    int two=calendar.get(Calendar.DATE);
   
    String twostr=Integer.toString(two);
 
       //List<WebElement> rows = tableCalendar.findElements(By.tagName("tr"));
 
        List<WebElement> columns = tableCalendar.findElements(By.tagName("td"));
 
          for (WebElement cell: columns) 
          {
            
           if (cell.getText().equals(twostr)) 
           {
               cell.click();
            	  break;
           }
         }
        return new SpecificDate(driver);
	} 
	
	@FindBy(xpath="//button[text()='Next']")
	WebElement nextButton;
	public SelectTime clickNext()
	{
		nextButton.click();
		return new SelectTime(driver);
	}
            	 
}
