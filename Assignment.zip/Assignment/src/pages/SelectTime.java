package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class SelectTime {
	
	private WebDriver driver;

	public SelectTime(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
@FindBy(xpath="//select[contains(@data-test,'step_time')]")
WebElement dropDown;
public SelectTime selectTime()
{
	 Select sel=new Select(dropDown);
     sel.selectByIndex(1);
     return new SelectTime(driver);
}

@FindBy(xpath="//button[text()='Next']")
WebElement nextButton;
public EmailAddressField clickNext()
{
	nextButton.click();
	return new EmailAddressField(driver);
}
}
