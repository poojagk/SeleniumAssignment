package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EmailAddressField {
	private WebDriver driver;

	public EmailAddressField(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	} 

	@FindBy(xpath="//div[@data-test='close_button']")
	WebElement closeButton;
	
	public EmailAddressField clickClose()
	{
		closeButton.click();
		return new EmailAddressField(driver);
	}
	
	@FindBy(xpath="//div[text()='Complete Request']")
	WebElement optionSelect;
	public void optionSelection()
	{
		optionSelect.click();
		
	}
	
}
