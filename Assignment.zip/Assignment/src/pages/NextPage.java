package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import startup.Startapp;

public class NextPage extends Startapp {
	
	private WebDriver driver;

	public NextPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//button[contains(text(),'Next')]")
	WebElement nextButton;
	public ProblemSelection clickNext()
	{
		nextButton.click();
		return new ProblemSelection (driver);
	}
	
	
}
