package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProblemFacing {
	
	private WebDriver driver;

	public ProblemFacing(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[text()='Leak in a pipe']/preceding-sibling::div")
	WebElement prob;
	public ProblemFacing selectProblem()
	{
		prob.click();
		return new ProblemFacing(driver);
	}
	
	@FindBy(xpath="//button[text()='Next']")
	WebElement nextButton;
	public AdditionalComments clickNext()
	{
		nextButton.click();
		return new AdditionalComments(driver);
	}

}
