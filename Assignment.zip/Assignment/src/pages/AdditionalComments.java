package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdditionalComments {
	
	private WebDriver driver;

	public AdditionalComments(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(xpath="//textarea[contains(@class,'text')]")
	WebElement textArea;
	public AdditionalComments enterComments()
	{
		textArea.sendKeys("Please bring the necessary items");
		return new AdditionalComments(driver);
	}
	
	@FindBy(xpath="//button[text()='Next']")
	WebElement nextButton;
	public SelectPlumbingDate clickNext()
	{
		nextButton.click();
		return new SelectPlumbingDate(driver);
	}
	
}
