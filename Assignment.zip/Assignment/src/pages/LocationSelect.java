package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import startup.Startapp;

public class LocationSelect {
	
	private WebDriver driver;

	public LocationSelect(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="(//input[contains(@placeholder,'Where?')])[2]")
	WebElement location;
	public LocationSelect selectArea()
	{		
		location.clear();
		return new LocationSelect(driver);
	}
	
	@FindBy(xpath="//div[@data-val='Chennai']")
	WebElement locationName;
	public LocationSelect typeLocation()
	{
		location.sendKeys("Chennai");
		return new LocationSelect(driver);
	}
	
	public LocationSelect clickLocation()
	{
		locationName.click();
		return new LocationSelect(driver);
	}
	
	
	@FindBy(xpath="(//input[@type='submit']) [1]")
	WebElement button;
	public NextPage clickSubmit()
	{
		button.click();
		return new NextPage(driver);
	}
	
}
