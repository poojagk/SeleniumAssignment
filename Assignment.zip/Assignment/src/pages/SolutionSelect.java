package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SolutionSelect {

	private WebDriver driver;

	public SolutionSelect(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//div[text()='Replace']/preceding-sibling::div")
	WebElement selectSolution;
	public SolutionSelect solSelect()
	{
		selectSolution.click();
		return new SolutionSelect(driver);
	}
	
	@FindBy(xpath="//button[text()='Next']")
	WebElement nxtbutton;
	public ProblemFacing clickNext()
	{
		nxtbutton.click();
		return new ProblemFacing(driver);
	}
	
}
