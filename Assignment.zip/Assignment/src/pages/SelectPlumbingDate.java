package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SelectPlumbingDate {
	
	private WebDriver driver;

	public SelectPlumbingDate(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath="//div[text()='On a specific date']")
	WebElement selDate;
	public SelectPlumbingDate selectDate()
	{
		selDate.click();
		return new SelectPlumbingDate(driver);
	}
	
	@FindBy(xpath="//button[text()='Next']")
	WebElement nextButton;
	public SpecificDate clickNext()
	{
		nextButton.click();
		return new SpecificDate(driver);
	}
}
