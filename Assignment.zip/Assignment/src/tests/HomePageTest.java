package tests;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pages.AdditionalComments;
import pages.EmailAddressField;
import pages.LocationSelect;
import pages.NextPage;
import pages.ProblemFacing;
import pages.ProblemSelection;
import pages.SelectPlumbingDate;
import pages.SelectTime;
import pages.SolutionSelect;
import pages.SpecificDate;
import startup.Startapp;

public class HomePageTest extends Startapp {
	
	@Test(priority=1)
	public void runTest()
	{
            LocationSelect select=new LocationSelect(driver);
			select.selectArea();
			select.typeLocation();
			select.clickLocation();
			select.clickSubmit();
			
	}
	
	@Test(priority=2)
	public void runNextPage()
	{
            NextPage nxt=new NextPage(driver);
		    nxt.clickNext();
			
	}
	
	@Test(priority=3)
	public void problemSelection()
	{
		ProblemSelection prbsel=new ProblemSelection(driver);
		prbsel.problemSelect();
		prbsel.clickNext();
	}
	
	@Test(priority=4)
	public void solutionSelection()
	{
		SolutionSelect solsel=new SolutionSelect(driver);
		solsel.solSelect();
		solsel.clickNext();
	}
	
	@Test(priority=5)
	public void problemFacing()
	{
		ProblemFacing problem=new ProblemFacing(driver);
		problem.selectProblem();
		problem.clickNext();
	}
	@Test(priority=6)
	public void addComments()
	{
       AdditionalComments addComments=new AdditionalComments(driver);
       addComments.enterComments();
       addComments.clickNext();
	}
	
	@Test(priority=7)
	public void selectPlumbingTime()
	{
		SelectPlumbingDate selectDate=new SelectPlumbingDate(driver);
		selectDate.selectDate();
		selectDate.clickNext();
	}
	
	@Test(priority=8)
	public void specificDateSelect()
	{
		SpecificDate spdate=new SpecificDate(driver);
		spdate.CalendarMethod();
		spdate.clickNext();
	}
	@Test(priority=9)
	public void selectTime()
	{
		SelectTime sel=new SelectTime(driver);
		sel.selectTime();
		sel.clickNext();
	}
	@Test(priority=10)
	public void viewEmailAddress()
	{
		EmailAddressField view = new EmailAddressField(driver);
		view.clickClose();
		view.optionSelection();
	}
	}


